package com.cg.placementproject.Service;

import java.util.List;
import com.cg.placementproject.entity.Placement;

public interface PlacementService {
	public void addPlacement(Placement placement);
	
	public List<Placement> searchPlacement(int id);
	public List<Placement> getAllData();
	
	public Placement updatePlacement(int id, Placement placement);
	public Placement deletePlacement(int id3, Placement placement);	 
	
}
