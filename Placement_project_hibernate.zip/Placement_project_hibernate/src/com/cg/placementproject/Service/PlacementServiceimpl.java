package com.cg.placementproject.Service;

import java.util.List;

import com.cg.placementproject.Repository.PlacementRepository;
import com.cg.placementproject.Repository.Placementrepositoryimpl;
import com.cg.placementproject.entity.Placement;

public class PlacementServiceimpl implements PlacementService{

	PlacementRepository pri; 
	
	public PlacementServiceimpl() {
		pri=new Placementrepositoryimpl();
	}
	
	@Override
	public void addPlacement(Placement placement) {
		pri.startTransaction();
		pri.addPlacement(placement);
		pri.endTransaction();
	}

	@Override
	public List<Placement> searchPlacement(int id) {
		return pri.searchPlacement(id);
	}

	@Override
	public List<Placement> getAllData() {
		return pri.getAllData();
	}

	@Override
	public Placement updatePlacement(int id, Placement placement) {
		return pri.updatePlacement(id,placement);
	}

	@Override
	public Placement deletePlacement(int id3, Placement placement) {
		return pri.deletePlacement(id3,placement);
	}

}
