package com.cg.placementproject;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import com.cg.placementproject.Service.PlacementService;
import com.cg.placementproject.Service.PlacementServiceimpl;
import com.cg.placementproject.entity.Placement;

public class Placementclient {
	public static void main(String args[]) {
		
		PlacementService cs=new PlacementServiceimpl();
		String dateString = "16-10-2008";
		
		//Creating or adding placement data to placement database
		Placement placement=new Placement(12, "Rahul", "westberry", dateString,"Bachelor degree", 2020);
		cs.addPlacement(placement);
	
		//Retrieving the data
		int id1;
		Scanner sc = new Scanner(System.in);
		try {
			System.out.print("Please enter placement ID to print that placement details: ");
			id1=sc.nextInt();
			System.out.println();
			List<Placement> li= cs.searchPlacement(id1);
			for(Placement p : li)
				System.out.println(p);
		}
		catch(Exception e) {
			System.out.println(e+ "\n Please enter correct data to Add..!");
		}

		//Retrieve all data Operation
		System.out.println("\n" + "Printing All Data From Placement " + "\n");
		List<Placement> li4=cs.getAllData();
		Iterator<Placement> it=li4.iterator();
		while(it.hasNext())
			System.out.println(it.next());

		//Update placement data operation
		int id2;
		try {
			System.out.print("\n" + "Please enter Placement ID to update that Placement student name: ");
			id2=sc.nextInt();
			System.out.println();
			Placement c1=cs.updatePlacement(id2,placement);
			System.out.println(c1);
		}
		catch (Exception e) {
			System.out.println(e+ "\n Please enter correct Update data..!");
		}
			
		//Delete id Operation
		try {
			System.out.print("\n" + "Please enter placement ID to Delete that data: ");
			int id3=sc.nextInt();
			System.out.println();
			System.out.print(cs.deletePlacement(id3,placement) + "\n" + "\n"+ "deleted successfully");
		}
		catch(Exception e) {
			System.out.println(e+ "Invalid input: Please enter valid data to delete that entire row..!");
		}
		sc.close();
	}
}
