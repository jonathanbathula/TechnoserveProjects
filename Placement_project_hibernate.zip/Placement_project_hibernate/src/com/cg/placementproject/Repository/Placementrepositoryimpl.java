package com.cg.placementproject.Repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.placementproject.entity.Placement;

public class Placementrepositoryimpl implements PlacementRepository {

	EntityManager em;
	public Placementrepositoryimpl() {
		em=Configuration.createEntityManager();
	}

	@Override
	public void startTransaction() {
		em.getTransaction().begin();
	}

	@Override
	public void endTransaction() {
		em.getTransaction().commit();
	}
	@Override
	public void addPlacement(Placement placement) {
		em.persist(placement);
	}
	
	@Override
	public List<Placement> searchPlacement(int id) {
		String query="Select c from Placement c WHERE c.id like : id";
		TypedQuery<Placement> t=em.createQuery(query, Placement.class);
		t.setParameter("id", id);
		return t.getResultList();
	}
	
	@Override
	public Placement updatePlacement(int id, Placement placement) {
		em.getTransaction().begin();
		Placement placement1 = em.find(Placement.class, id);
		placement1.setName("Dass");
		em.getTransaction().commit();
		return placement1;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Placement> getAllData() {
		Query query= em.createNamedQuery("getAllData");
		List<Placement> list= query.getResultList();
		return list;
	}

	@Override
	public Placement deletePlacement(int id3, Placement placement) {
		
		em.getTransaction().begin();
		Placement placement2 = em.find(Placement.class, id3);
		em.remove(placement2);
		em.getTransaction().commit();
		return placement2;
	}

}
