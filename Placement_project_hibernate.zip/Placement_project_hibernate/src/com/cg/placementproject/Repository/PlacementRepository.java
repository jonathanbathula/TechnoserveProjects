package com.cg.placementproject.Repository;

import java.util.List;


import com.cg.placementproject.entity.Placement;

public interface PlacementRepository {
		
	public void addPlacement(Placement placement);
	
	public List<Placement> searchPlacement(int id);
	public List<Placement> getAllData();
	
	public Placement updatePlacement(int id, Placement placement);
	public Placement deletePlacement(int id3, Placement placement);	 
	
	public void startTransaction();
	public void endTransaction();
}
 