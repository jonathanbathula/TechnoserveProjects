package com.technoserve.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.technoserve.entity.Placement;
import com.technoserve.repository.PlacementRepository;

@Service
public class Placementserviceimpl implements PlacementService {

	
	@Autowired
	PlacementRepository cr;
	
	public Placementserviceimpl(PlacementRepository cr) {
		super();
		this.cr=cr;
	}
    
	@Override
	public List<Placement> getAllPlacement() {
		return cr.findAll();
		
	}

	@Override
	public Placement savePlacement(Placement placement) {
		return cr.save(placement);
	}

	@Override
	public Placement getPlacementById(int id) {
		Placement placement= cr.findById(id).get();
		return placement;
	}

	@Override
	public Placement updatePlacement(int id) {
		Placement placement= cr.findById(id).get();
		placement.setQualification("B.tech");
		cr.save(placement);
		return placement;
	}

	@Override
	public String deletePlacement(int id) {
		Placement placement= cr.findById(id).get();
		cr.delete(placement);
		return placement + "deleted successfully";
	}

}
