package com.technoserve.Service;

import java.util.List;

import com.technoserve.entity.Placement;
public interface PlacementService {

     
	 
	 Placement savePlacement(Placement placement);
	 
	 Placement getPlacementById(int id);
	 
	 Placement updatePlacement(int id);
	 
	 String deletePlacement(int id);
     
	 List<Placement> getAllPlacement();
		
		
	

}
