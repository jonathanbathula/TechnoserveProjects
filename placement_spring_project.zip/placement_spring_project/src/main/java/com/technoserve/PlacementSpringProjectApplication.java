package com.technoserve;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacementSpringProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacementSpringProjectApplication.class, args);
	}

}
