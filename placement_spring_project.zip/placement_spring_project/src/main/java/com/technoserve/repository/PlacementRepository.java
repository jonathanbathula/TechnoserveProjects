package com.technoserve.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.technoserve.entity.Placement;

public interface PlacementRepository extends JpaRepository<Placement,Integer>{

}
