package com.technoserve.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.technoserve.Service.PlacementService;
import com.technoserve.entity.Placement;


@RestController
@RequestMapping
public class Controller {
	
	@Autowired
	PlacementService cs;
	
	// to get all placement records
	@GetMapping("/getplacements")
	public List<Placement> getAllPlacement(){
		 return cs.getAllPlacement();
	}
	
	//to add placement record 
	@PostMapping("/addplacement")
	public void addPlacement(@RequestBody Placement placement) {
		 cs.savePlacement(placement);
	}
	
	//to get placement record by id
	@GetMapping("/getplacement/{Id}")
	public Placement getPlacementById(@PathVariable int Id) {
		return cs.getPlacementById(Id);
	}
	
	//to update record by id
	@PutMapping("/updateplacement/{Id}")
	public Placement updatePlacement(@PathVariable int Id) {//, String Location) {
		return cs.updatePlacement(Id);//, Location);
	}
	
	@DeleteMapping("deletemapping/{Id}")
	public String deletePlacement(@PathVariable int Id) {
		return cs.deletePlacement(Id);
	}

}
