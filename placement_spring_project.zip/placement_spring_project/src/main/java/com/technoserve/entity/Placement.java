package com.technoserve.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import javax.persistence.Table;

@Table(name="Placementdb")
@Entity
public class Placement implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	private int id;
	private int year;
	private String name;
	private String collegeName;
	private String date;
	private String qualification;
	
	public Placement() {
		
	}
	public Placement(int id, String name, String collegeName, String date, String qualification, int year) {
		this.id = id;
		this.name = name;
		this.collegeName = collegeName;
		this.date = date;
		this.qualification = qualification;
		this.year = year;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	@Override
	public String toString() {
		return "Placement [id=" + id + ", name=" + name + ", collegeName=" + collegeName + ", date=" + date
				+ ", qualification=" + qualification + ", year=" + year + "]";
	}
	     	
}